import React from 'react'
import Nav from '../components/nav'
import About from '../components/about_us'
import Footer from '../components/footer'

const home = () => {
  return (
    <>
    <div className='bg-indigo-950'>
        <Nav/>
    </div>
    <div><About/></div>
    <div>
        <Footer/>
    </div>
    </>
  )
}

export default home