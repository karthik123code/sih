import React from 'react'
import { BsFacebook,BsTwitter,BsInstagram,BsPinterest } from 'react-icons/bs';
import DigImage from '../assets/digitalimg.jpg';

const about_us = () => {
  return (
    <>
    <section className='flex justify-around items-center p-10 space-x-10 lg:flex-row ssm:flex-col ssm:space-y-10 text-white bg-blue-900'>
        <div className='lg:w-1/2 ssm:w-fit '>
        <h1 className='text-6xl mb-5 text-slate-300'>About Us</h1>
        <hr/>
        <p className='mt-10 text-xl text-slate-300 font-sans '>Parallax minds is an online social media parsing platform aimed to aid crime investigators in collecting posts and information posted on suspects social media profiles by compiling the data in a detailed document format.</p>
        </div>
        <div className='w-1/3 items-center ssm:w-fit'>
            <img src={DigImage} alt="" width={350} height={300} className='rounded-full w-full border-8 border-white opacity-25'/>
        </div>
        
    </section>
    <section className='flex p-12 space-x-10 lg:flex-row ssm:flex-col ssm:space-y-10 text-white text-6xl bg-blue-400'>
    <div className='lg:w-1/2 ssm:w-fit'>
            <h1 className='text-6xl mb-5 text-slate-300'>
            Platforms Available</h1>
            <hr/>
            <div className='flex justify-around items-center mt-10 space-x-8 cursor-pointer'>
                <BsFacebook/>
                <BsInstagram/>
                <BsTwitter/>
                <BsPinterest/>
            </div>
        </div>
        </section>
    </>
  )
}

export default about_us